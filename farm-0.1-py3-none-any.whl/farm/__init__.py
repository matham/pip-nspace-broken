print('Imported farm')

my_name = 'Cow'