
"""The following code is required to make the dependency binaries available to
kivy when it imports this package.
"""



print('Imported farm.deps.glew')